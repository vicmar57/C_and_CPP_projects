/* Assignment: 6
Author1: Victor Martinov,
ID: 307835249
Author2: Tsur Avneri,
ID: 308134485
 */

////////////////////////as we ere taught , Template classes are written in header file only////////////////////////////

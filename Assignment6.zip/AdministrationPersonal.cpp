/* Assignment: 6
Author1: Victor Martinov,
ID: 307835249
Author2: Tsur Avneri,
ID: 308134485
 */

#include "AdministrationPersonal.h"

AdministrationPersonal::~AdministrationPersonal() //Administration Personal's destructor
{
}
AdministrationPersonal::AdministrationPersonal() //Administration Personal's empty constructor
:Worker()
{
	officeLoc="";
}

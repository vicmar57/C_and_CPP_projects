/* Assignment: 3
Author1: Victor Martinov,
ID: 307835249
Author2: Tsur Avneri,
ID: 308134485
 */

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define numberOfCandidates 7
typedef struct candidate//repesents a candidate in the race for the presidency or membership.
{
	char name[31];//name of the candidate
	int runningFor;//the role hes candidate is running for
	int voteCount;//the number of votes counted.
}candidate;
typedef struct Vote {//represents a single vote by a voter(acts like a linked list)
	char name [31];//name of the voter
	char id [10];//id of the voter
	char votedFor [31];//name of the candidate the voter voted to
	int presOrMem;//the role the candidate is running for
	struct Vote *next;//the next vote of the specific voter
} Vote;

char * calculateWinners(candidate *candids[numberOfCandidates]);
void AddCandidCount (candidate *candids[numberOfCandidates], Vote *temp);
char* checkvalidity (Vote* stu,candidate *candids[numberOfCandidates]);
void freelinks (Vote * head);
void GenCandFiles(char * candidates, char *votes[], int uni_count);
int areAllFilesEOF (FILE ** Unis,int uni_count);
int findMinID (Vote ** voters,int uni_count);
void GenCandFiles(char * candidates, char  *votes[], int uni_count)//generates the files as requested in the assignment
{//the variables:candidates-the path for the candidates txt file,votes-the path for the universities txt files,uni_count-the number of unis participating
	int i,j=0; // LAST - reached the final voter.
	char  stuName[31]={0},*voteRes,*Winners,* uninames[uni_count],minID[10]={0};
	Vote * voters[uni_count],*temp;
	candidate *candids[numberOfCandidates]={0};//an array with pointers to the candidates
	FILE *candiF,*candiWF,*non_valid_summary,*results,* voteFiles[uni_count];//uniF-votes file of a specific university. candiF - candidates details files. candiWf - file for each of candidates votes.
	for (i=0;i<uni_count ;i++)
	{
		uninames[i]=(char*)calloc(1000,sizeof(char));
		voters[i]= (Vote*)calloc(1,sizeof(Vote));
		//voteFiles[i]= (FILE * )calloc(1, sizeof(FILE));
		voteFiles [i]= fopen(votes[i],"r");// opening all university vote files.

		fscanf(voteFiles[i],"%[^\n]%*c",uninames[i]);
		fscanf(voteFiles[i],"%30[A-Z a-z]%9s%30[A-Z a-z]%1d%*c",voters[i]->name,voters[i]->id,voters[i]->votedFor,&voters[i]->presOrMem);
	}
	candiF = fopen(candidates,"r");
	if(!candiF) exit(1);
	results=fopen("results.txt","w");
	non_valid_summary=fopen("non_valid_summary.txt","w");
	fclose(non_valid_summary);
	fclose(results);
	for(i=0;i<numberOfCandidates;i++)//create and close the candidate files
	{
		candids[i]=(candidate*)calloc(1,sizeof(candidate));
		fscanf(candiF,"%[a-z A-Z]%1d%*c",candids[i]->name,&candids[i]->runningFor);
		candiWF=fopen(candids[i]->name,"w");
		fclose(candiWF);
	}

	while(!areAllFilesEOF(voteFiles,uni_count))//as long as there are files that didnt end
	{
		strcpy(minID,"999999999");
		for (i=0;i<uni_count ; i++)
		{
			if (!feof(voteFiles[i]) && strcmp(minID, voters[i]->id ) >0)
			{
				strcpy(	minID, (voters[i])->id);
				j=i;
			}
		}
		fscanf(voteFiles[j],"%[a-z A-Z]",stuName);
		temp=voters[j];
		while( !strcmp(stuName,voters[j]->name))//read from the file all of the votes of the same voter
		{

				temp->next = (Vote*)calloc(1,sizeof(Vote));
				strcpy(temp->next->name,stuName);
				fscanf(voteFiles[j],"%9s",temp->next->id);
				fscanf(voteFiles[j],"%30[A-Z a-z]",temp->next->votedFor);
				fscanf(voteFiles[j],"%1d%*c",&temp->next->presOrMem);
				temp = temp->next;
				fscanf(voteFiles[j],"%[a-z A-Z]",stuName);
				if( feof(voteFiles[j]))
					break;
		}
		temp=voters[j];
		voteRes=checkvalidity(voters[j],candids);//check if the previous voter voted legally
		if(!*voteRes)
		{
			while(temp)//write the voter in the candidate file
			{
				candiWF=fopen(temp->votedFor,"a");
				fprintf(candiWF , "%s ", temp->id);
				fprintf(candiWF,"%s\n",uninames[j]);
				AddCandidCount (candids,temp);
				fclose(candiWF);
				temp=temp->next;
			}
			freelinks(voters[j]);//free the previous voter's list
			voters[j] = (Vote*)calloc(1,sizeof(Vote)); // make new voter's votes list
			strcpy(voters[j]->name,stuName);
			fscanf(voteFiles[j],"%9s%30[A-Z a-z]%1d%*c",voters[j]->id,voters[j]->votedFor,&voters[j]->presOrMem);
		}
		else//the previous voter didn't vote legally-write him in the invalid votes file
		{
			non_valid_summary=fopen("non_valid_summary.txt","a");
			fprintf(non_valid_summary , "%s ", voters[j]->id);
			fprintf(non_valid_summary,"%s ",uninames[j]);
			fprintf(non_valid_summary,"%s\n",voteRes);
			fclose(non_valid_summary);
			freelinks(voters[j]);
			voters[j] = (Vote*)calloc(1,sizeof(Vote)); // make new voter's votes list
			strcpy(voters[j]->name,stuName);
			fscanf(voteFiles[j],"%9s%30[A-Z a-z]%1d%*c",voters[j]->id,voters[j]->votedFor,&voters[j]->presOrMem);
		}

	}

	results=fopen("results.txt","a");
	if(!results)exit(1);
	for (i=0 ; i<numberOfCandidates ; i++)//count the votes for the candidates
	{
		fprintf(results,"%s ",candids[i]->name);
		fprintf(results,"%d\n",candids[i]->voteCount);
	}
	fprintf(results,"%s","\n");//print the winners
	fprintf(results,"%s\n","--- Winners ---");
	fprintf(results,"%s ","Head:");
	Winners = calculateWinners(candids);
	fprintf(results,"%s",Winners);
	fclose(results);
	free(Winners);
	for(i=0;i<numberOfCandidates;i++)
	{
		free(candids[i]);
	}
	fclose(candiF);
	for(i=0;i<uni_count;i++)
	{
	fclose(voteFiles[i]);
	free(uninames[i]);
	}
}
void freelinks (Vote * head)//free the voter's votes(head- the first vote of the voter)
{


	if (head->next)
	{
		freelinks(head->next);
		free(head);
		head=NULL;
	}
	else
	{
		free(head);
		head=NULL;
	}
}
char* checkvalidity (Vote* stu,candidate *candids[numberOfCandidates])//checks the validity of the votes
{//stu-the first vote of the voter,candids-the array containing the candidates details. returns:a string describing the invalidity
	char *res = (char*)calloc(31,sizeof(char));//res will contain the string that describes the validity of the vote it wont contain anything if its legal
	int i,foundname=0,vforpres=0,vformem=0,nodecount=0,dup=0;
	Vote* temp= stu,*walker = stu;//walker is used to check for duplications by comparison with temp
	while(temp)//checks for duplication
	{
		if (temp->next)
			walker=temp->next;
		else break;
		while(walker)
		{
			if (!strcmp(temp->votedFor,walker->votedFor))//if the same candidate appears twice
				dup++;
			walker= walker->next;
		}
		if (dup>=1)//if duplication is detected
		{
			strcat(res,"Duplicate ");
			return res;
		}
		if(temp->next)
			temp = temp->next;
		else
			break;
	}
	temp=stu;
	while (temp)//checks for the conditions of invalidity and inexistence
	{
		for(i=0;i<numberOfCandidates;i++)
		{
			if (!strcmp(temp->votedFor,candids[i]->name))
			{
				foundname++;
				if (temp->presOrMem == candids[i]->runningFor)
				{
					if(temp->presOrMem==1)
					{
						vforpres++;
						break;
					}
					else if(temp->presOrMem==2)
					{
						vformem++;
						break;
					}
					else strcat(res,"Not_Valid "); //if the vote was different from 1 or 2
					return res;
				}
				else
				{
					strcat(res, "Not_Exist");//no match between the roles of the specific candidate
					return res;
				}
			}
		}
		nodecount++;
		if(temp->next)
			temp = temp->next;
		else
			break;
	}
	if(!(vforpres<=1 && vformem<=2) )//voted more than twice for member or more than once for president
	{
		strcat(res, "Not_Valid ");
		return res;
	}
	if (foundname!=nodecount)//the candidate name wasn't found in the candidate array
	{
		strcat(res, "Not_Exist ");
		return res;
	}
	return res;
}
void AddCandidCount (candidate *candids[numberOfCandidates], Vote *temp)//adds 1 for the candidate vote count
{//candids-the array of the candidates,temp-the specific vote
	int i;
	for (i=0;i<numberOfCandidates;i++)
	{
		if (!strcmp(temp->votedFor,candids[i]->name))
		{
			candids[i]->voteCount++;
			break;
		}
	}
}
char * calculateWinners(candidate *candids[numberOfCandidates])//return the string of the winners(1 for pres 2 for membership)
{
	char *Winners = (char*)calloc(93,sizeof(char));//max name of the winner*3 with spaces and \0
	int i,j,Mems=0;
	candidate *tmp, *HeadWinner;
	for (i=0;i<numberOfCandidates;i++)//bubble sort
	{
		for (j=0;j<numberOfCandidates-1;j++)
		{
			if (candids[j]->voteCount < candids[j+1]->voteCount)
			{
				tmp = candids[j];
				candids[j] = candids[j+1];
				candids[j+1]=tmp;
			}
		}
	}
	for (i=0;i<numberOfCandidates;i++)//finds the winner for the presidency
	{
		if (candids[i]->runningFor==1)
		{
			HeadWinner =  candids[i];
			for (i=0;i<numberOfCandidates;i++)
			{
				if (candids[i]->runningFor==1 && candids[i]->voteCount > HeadWinner->voteCount)
					HeadWinner = candids[i];
			}
		}
	}//takes the first 2 candidates(for membership) from the array (sorted from bigger-lower) and concatenates them to winners
	strcat(Winners, HeadWinner->name);
	strcat(Winners, " \n");
	for (i=0;i<numberOfCandidates;i++)
	{
		if (candids[i]->runningFor==2 &&  Mems <2)
		{
			strcat(Winners, candids[i]->name);
			strcat(Winners, " \n");
			Mems++;
		}
		else if (Mems ==2) break;
	}
	return Winners;
}
int findMinID (Vote ** voters,int uni_count)//find the min ID of the voters array
{
	int i,imin=0;
	char minID [10];
	strcpy (minID, voters[0]->id);
	for (i=1;i<uni_count ; i++)
	{
		if (strcmp(minID, voters[i]->id ) >0)
		{
			strcpy(	minID, (voters[i])->id);
			imin=i;
		}
	}
	return imin;
}
int areAllFilesEOF (FILE ** Unis,int uni_count)//scans if all of the files finished reading
{
	int i;
	for(i=0;i<uni_count;i++)
	{
		if (!feof(Unis[i]))
		{
			return 0;
		}
	}
	return 1;
}
int main()//this is our main you can delete it if you want to
{
	char *votes[3]={};
	votes[0]= "uni1";
	votes[1]= "uni2";
	votes[2]= "uni3";
	char * can = "candidates";
	GenCandFiles(can, votes, 3);
	return 0;
}
